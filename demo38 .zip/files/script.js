$(document).ready(function() {	
	function calc() {
		amount = parseFloat($('#calc_sum').val());
		
		if (amount >= planData.min && planData.max >= amount) {
			$('#profit').text(parseInt(planData.percent - 100));
			$('#prib').text(numberFormat(amount * (planData.percent / 100)));
		} else {
			clean_calc();
		}

		// console.log(planData);
	}
	
	function clean_calc() {
		$('#profit').text('0');
		$('#prib').text('0.00');
	}
	
    $('#calc_sum').on('keyup click change', function (e) {
		e.preventDefault();
		calc();
	});
	$('#formcalc').on('submit', function (e) {
		e.preventDefault();
		calc();
	});
});

function numberFormat(number) { 
	return (Math.floor(number * 100) / 100).toFixed(2);
}
