<footer>
<div class="footer_menu"></div>
<div class="footer_bottom cfix">
<div class="footer_bottom_copyright">© <a href="https://ed-script.pro" target="_blank">P & S</a> © Все права 3ащищены / <?=$host?></div>
<div class="footer_bottom_copyright" style="float:right;">
Нет Payeer-кошелька? <a href="https://payeer.com/" target="_blank">Зарегистрируйте прямо сейчас!</a>
</div>
<div class="footer_bottom_ssl"></div>
</div>
<center><a href="https://php-scripts.ru" target="_blank"><img src="https://php-scripts.ru/wp-content/uploads/2019/02/quote-logo.png" width="72px" height="32px" alt="Скрипты хайпов" title="скачать"></a></center>
</footer>

</body>
 </html>