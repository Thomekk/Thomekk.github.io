<?php if(!defined('SCRIPT_BY_SIRGOFFAN')){
echo ('Выявлена попытка взлома!');
exit();
}
?>
<section class="statistic">
<div class="statistic cfix">
<h1>
<span>Лучшие партнеры</span>
<div class="line"></div>
</h1>
<div id="stats" align="center">
<div class="stats_1">
<table>
<thead>
<tr>
<td colspan="5" class="with_bg">Топ 10 партнеров</td>
</tr>
<tr>
 	<td align="center"><b>Место</b></td> 
	<td align="center"><b>Кошелек</b></td>
	<td align="center"><b>Пригласил человек</b></td>
	<td align="center"><b>Рефералы вложили</b></td>
</tr>  
</thead>
<tbody> 

<? 

$checkdeps=$db->getOne("SELECT id FROM ?n WHERE i_have_refs_as_curator>0 LIMIT 1","ss_users");
if($checkdeps>0){
$depositsrow=$db->query("SELECT * FROM ?n WHERE i_have_refs_as_curator>0 ORDER BY i_have_refs_as_curator DESC LIMIT 10","ss_users");
  $i=1;
while($deposits=$db->fetch($depositsrow)){?>  
	<tr align="center" height="25">
	
<?
$wallet=substr($deposits['wallet'], 0, -3); 
?>	
	
	<td align="center"><?=$i?></td>	
	<td align="center"><b><?=$wallet?>***</b></td>
    <td align="center"><?=$deposits['i_have_refs_as_curator']?> чел.</td>
<?
$checkdeps=$db->getOne("SELECT SUM(summa) as motherfucker FROM ?n WHERE curatorid=?i","deposits",$deposits['id']);
/*$checkdeps=$db->fetch($checkdeps);
$checkdeps=$checkdeps['motherfucker'];*/
if(empty($checkdeps)){$checkdeps=0;}
?>		
    <td align="center"><?=$checkdeps?> <i class="fas fa-ruble-sign"></i></td>	

<?

switch($i)
{
	case 1: $thislvlprize = 40000; break;
	case 2: $thislvlprize = 30000; break;	
	case 3: $thislvlprize = 16000; break;	
	case 4: $thislvlprize = 14500; break;	
	case 5: $thislvlprize = 13000; break;	
	case 6: $thislvlprize = 11300; break;	
	case 7: $thislvlprize = 10500; break;	
	case 8: $thislvlprize = 9200; break;	
	case 9: $thislvlprize = 8400; break;	
	case 10: $thislvlprize = 7600; break;	
	case 11: $thislvlprize = 6200; break;	
	case 12: $thislvlprize = 5100; break;	
	case 13: $thislvlprize = 4000; break;
	case 14: $thislvlprize = 3400; break;	
	case 15: $thislvlprize = 2300; break;	
	case 16: $thislvlprize = 1800; break;	
	case 17: $thislvlprize = 1400; break;	
	case 18: $thislvlprize = 1000; break;	
	case 19: $thislvlprize = 800; break;	
	case 20: $thislvlprize = 500; break;	
	case 21: $thislvlprize = 300; break;	
	case 22: $thislvlprize = 200; break;	
	case 23: $thislvlprize = 150; break;	
	case 24: $thislvlprize = 100; break;		
	case 25: $thislvlprize = 50; break;		
}
?>	
    	
  	</tr>	
	
	
<?$i++;}}else{?> 
<center>Данные пока не доступны</center>
<?}?>

</tbody>
</table> 
</div>
</div>
</div>
</section>

<?/*-------------------*//*
Web-site: vk.com/id457351861
*//*-------------------*/?>