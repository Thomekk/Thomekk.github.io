<?php if(!defined('SCRIPT_BY_SIRGOFFAN')){
echo ('Выявлена попытка взлома!');
exit();
}
?>
<section class="statistic">
<div class="statistic cfix">
<h1>
<span>Связь с администратором</span>
<div class="line"></div>
</h1>
<p align="left" style="width:1000px;padding-left:20px;padding-right: 20px;text-align: left;margin: 0 auto;color: #fff;border-radius: 8px;">
<center style="font-size: 20px;color: #fff;">
Перед обращением укажите в письме свой логин (payeer кошелек) <br><strong><span><?=$adminmail?></span></strong><br>
Наша группа Вконтакте - <a href="<?=$vkgrup?>" target="_blank">перейти</a><br>
Наш чат в Телеграм - <a href="<?=$telega?>" target="_blank">перейти</a>
</center>
</p>
</div>
</section>
<?/*-------------------*//*
Web-site: https://ed-script.pro
*//*-------------------*/?>