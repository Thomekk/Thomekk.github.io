<?php if(!defined('SCRIPT_BY_SIRGOFFAN')){
echo ('Выявлена попытка взлома!');
exit();
}
?>

                    500
			  
<?/*-------------------*//*
Web-site: vk.com/id457351861
*//*-------------------*/?>